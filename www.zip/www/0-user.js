var mysql = require('mysql');
const EventEmitter=require('events').EventEmitter;

var E=new EventEmitter();

var db = mysql.createConnection({
	host:'localhost',
	user:'root',
	password:'123456',
	database:'user'
})
db.query('select * from user',function(err,data){
	if(err){
		console.log('数据库方面错误')
	}else{
		console.log(data)
	}
})
//  处理接口
E.on('/news',function(req,res){
    var act=req.get.act;
    /*if(act=='add'){
        //添加新闻
        E.emit('news-add',req,res);
    }*/
    switch (act){
        case 'add':
            E.emit('news-add',req,res);
            break;
        case 'get':
            E.emit('news-get',req,res);
            break;
    }
});